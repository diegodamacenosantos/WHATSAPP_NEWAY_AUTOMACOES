const R = require('./whatsapp-regras');

module.exports = function (RED) {
    const ROTULOS = {
        parado: ['grey', 'parado'],
        sem_login: ['red', 'sem login'],
        aguardando_qr: ['yellow', 'aguardando QR'],
        conectando: ['yellow', 'conectando'],
        reconectando: ['yellow', 'reconectando'],
        substituida: ['red', 'sessão em outro lugar'],
        erro: ['red', 'erro'],
        online: ['green', 'online']
    };

    function Mensagem(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        const conta = RED.nodes.getNode(config.conta);
        const envio = config.tipo === 'envio';
        const numeroFixo = String(config.numeroFixo || '').replace(/\D/g, '');
        const lista = Array.isArray(config.numeros) ? config.numeros.map(n => (String(n).endsWith('@g.us') ? String(n) : R.canonico(n))) : [];
        let fila = { tamanho: 0, motivo: '', ate: 0 };

        if (!conta) {
            node.status({ fill: 'red', shape: 'ring', text: 'sem conta' });
            return;
        }

        function pintar() {
            if (conta.estado !== 'online') {
                const r = ROTULOS[conta.estado] || ['grey', conta.estado];
                node.status({ fill: r[0], shape: 'dot', text: r[1] });
                return;
            }
            if (envio && fila.tamanho > 0) {
                const resta = fila.ate ? Math.max(0, Math.ceil((fila.ate - Date.now()) / 1000)) : 0;
                const texto = 'fila ' + fila.tamanho + (fila.motivo ? ' · ' + fila.motivo : '') + (resta ? ' · ' + resta + ' s' : '');
                node.status({ fill: 'yellow', shape: 'dot', text: texto });
                return;
            }
            node.status({ fill: 'green', shape: 'dot', text: 'online ' + (conta.numero || '') });
        }

        function recusar(motivo, msg) {
            node.warn(motivo);
            node.status({ fill: 'red', shape: 'ring', text: motivo.slice(0, 60) });
            setTimeout(pintar, 4000);
        }

        const aoEstado = () => pintar();
        const aoFila = (f) => {
            fila = f;
            pintar();
        };
        const aoMensagem = (dados) => {
            const saidas = new Array(lista.length + 1).fill(null);
            saidas[0] = { payload: dados };
            if (lista.length) {
                const alvo = dados.grupo ? dados.grupo : R.canonico(dados.numero);
                lista.forEach((n, i) => {
                    if (n && n === alvo) saidas[i + 1] = { payload: Object.assign({}, dados) };
                });
            }
            node.send(saidas);
        };
        const aoRecusada = (motivo) => recusar(motivo);

        conta.eventos.on('estado', aoEstado);

        if (envio) {
            conta.eventos.on('fila', aoFila);
            conta.eventos.on('recusada', aoRecusada);
            node.on('input', function (msg, send, feito) {
                const p = msg.payload;
                if (numeroFixo) {
                    const texto = typeof p === 'string' ? p : (p && typeof p === 'object' ? p.mensagem : undefined);
                    const r = conta.enviar(null, numeroFixo, texto);
                    if (!r.ok) recusar(r.motivo, msg);
                } else if (!p || typeof p !== 'object') {
                    recusar('payload precisa ser objeto {numero, mensagem}', msg);
                } else {
                    const r = conta.enviar(p.grupo, p.numero, p.mensagem);
                    if (!r.ok) recusar(r.motivo, msg);
                }
                if (feito) feito();
            });
        } else {
            conta.eventos.on('mensagem', aoMensagem);
        }

        pintar();

        node.on('close', function (feito) {
            conta.eventos.removeListener('estado', aoEstado);
            conta.eventos.removeListener('fila', aoFila);
            conta.eventos.removeListener('recusada', aoRecusada);
            conta.eventos.removeListener('mensagem', aoMensagem);
            feito();
        });
    }

    RED.nodes.registerType('whatsapp-mensagem', Mensagem);
};
