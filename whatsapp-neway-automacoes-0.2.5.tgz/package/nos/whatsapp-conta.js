const fs = require('fs');
const path = require('path');
const EventEmitter = require('events');
const qrcode = require('qrcode-generator');
const R = require('./whatsapp-regras');

let biblioteca = null;
async function carregar() {
    if (!biblioteca) biblioteca = await import('@whiskeysockets/baileys');
    return biblioteca;
}

const silencioso = {
    level: 'silent',
    child() { return silencioso; },
    trace() {},
    debug() {},
    info() {},
    warn() {},
    error() {}
};

function dormir(ms) {
    return new Promise(r => setTimeout(r, ms));
}

function sorteio(min, max) {
    return Math.floor(min + Math.random() * (max - min));
}

function soDigitos(valor) {
    return String(valor || '').split('@')[0].split(':')[0].replace(/\D/g, '');
}

function desembrulhar(mensagem) {
    let m = mensagem;
    for (let i = 0; i < 5; i++) {
        const interno = m.ephemeralMessage || m.viewOnceMessage || m.viewOnceMessageV2 || m.documentWithCaptionMessage || m.editedMessage;
        if (interno && interno.message) m = interno.message;
        else break;
    }
    return m;
}

function analisar(mensagem) {
    const m = desembrulhar(mensagem);
    const texto = m.conversation
        || (m.extendedTextMessage && m.extendedTextMessage.text)
        || (m.imageMessage && m.imageMessage.caption)
        || (m.videoMessage && m.videoMessage.caption)
        || (m.documentMessage && m.documentMessage.caption)
        || (m.buttonsResponseMessage && m.buttonsResponseMessage.selectedDisplayText)
        || (m.listResponseMessage && m.listResponseMessage.title)
        || '';
    let tipo = 'outro';
    if (m.conversation || m.extendedTextMessage) tipo = 'texto';
    else if (m.imageMessage) tipo = 'imagem';
    else if (m.videoMessage) tipo = 'video';
    else if (m.audioMessage) tipo = 'audio';
    else if (m.documentMessage) tipo = 'documento';
    else if (m.stickerMessage) tipo = 'figurinha';
    else if (m.locationMessage) tipo = 'localizacao';
    else if (m.contactMessage) tipo = 'contato';
    else if (m.buttonsResponseMessage || m.listResponseMessage) tipo = 'texto';
    return { texto, tipo };
}

module.exports = function (RED) {
    const nucleos = new Map();

    function criarNucleo(id) {
        const node = { id: id, adotado: false, ultimoAcesso: Date.now() };
        const pasta = path.join(RED.settings.userDir || '.', 'whatsapp_' + node.id);
        const arquivoContatos = path.join(pasta, 'neway_contatos.json');
        const arquivoEnvios = path.join(pasta, 'neway_envios.json');

        node.eventos = new EventEmitter();
        node.eventos.setMaxListeners(100);
        node.estado = 'parado';
        node.detalhe = '';
        node.qrSvg = null;
        node.numero = null;

        let sock = null;
        let fechado = false;
        let tentativas = 0;
        let reconexao = null;
        let conectando = false;
        let contatos = {};
        let envios = [];
        let recentes = [];
        let fila = [];
        let rodando = false;
        let liberaEm = 0;
        const ultimaChave = new Map();
        const enviadas = new Set();

        function lerJson(arquivo, padrao) {
            try {
                return JSON.parse(fs.readFileSync(arquivo, 'utf8'));
            } catch (e) {
                return padrao;
            }
        }

        function gravarJson(arquivo, dados) {
            try {
                fs.mkdirSync(pasta, { recursive: true });
                fs.writeFileSync(arquivo, JSON.stringify(dados));
            } catch (e) {}
        }

        function carregarArquivos() {
            contatos = lerJson(arquivoContatos, {});
            const agora = Date.now();
            envios = lerJson(arquivoEnvios, []).filter(t => agora - t < R.DIA);
        }

        function mudar(estado, detalhe) {
            node.estado = estado;
            node.detalhe = detalhe || '';
            node.eventos.emit('estado', estado, node.detalhe);
        }

        function emitirFila(motivo, ate) {
            node.eventos.emit('fila', { tamanho: fila.length, motivo: motivo || '', ate: ate || 0 });
        }

        function temSessao() {
            const creds = lerJson(path.join(pasta, 'creds.json'), null);
            return !!(creds && creds.me);
        }

        async function resolverNumero(jid) {
            if (jid && jid.endsWith('@lid') && sock && sock.signalRepository && sock.signalRepository.lidMapping) {
                try {
                    const pn = await sock.signalRepository.lidMapping.getPNForLID(jid);
                    if (pn) return soDigitos(pn);
                } catch (e) {}
            }
            return soDigitos(jid);
        }

        function ehProprio(jid) {
            if (!jid || !node.numero) return false;
            const d = soDigitos(jid);
            if (d === node.numero) return true;
            const lid = sock && sock.user && sock.user.lid;
            return !!(lid && soDigitos(lid) === d);
        }

        function lembrarEnviada(id) {
            if (!id) return;
            enviadas.add(id);
            if (enviadas.size > 200) enviadas.delete(enviadas.values().next().value);
        }

        async function receber(m) {
            if (!m.message || !m.key) return;
            const remoto = m.key.remoteJid;
            if (!remoto || remoto === 'status@broadcast' || remoto.endsWith('@broadcast') || remoto.endsWith('@newsletter')) return;
            const proprio = !remoto.endsWith('@g.us') && ehProprio(m.key.remoteJidAlt || remoto);
            if (m.key.fromMe && !proprio) return;
            if (enviadas.has(m.key.id)) return;
            const grupo = remoto.endsWith('@g.us');
            const { texto, tipo } = analisar(m.message);
            if (tipo === 'outro' && !texto) return;
            let numero;
            if (proprio) {
                numero = node.numero;
            } else if (grupo) {
                numero = await resolverNumero(m.key.participantAlt || m.key.participant);
            } else {
                numero = await resolverNumero(m.key.remoteJidAlt || remoto);
            }
            const chave = grupo ? remoto : numero;
            contatos[chave] = { t: Date.now(), jid: remoto };
            if (!proprio) ultimaChave.set(chave, m.key);
            gravarJson(arquivoContatos, contatos);
            node.eventos.emit('mensagem', {
                numero: numero,
                mensagem: texto,
                nome: m.pushName || '',
                grupo: grupo ? remoto : null,
                tipo: tipo
            });
        }

        function janela(ms) {
            const agora = Date.now();
            return envios.filter(t => agora - t < ms);
        }

        function esperaLimites() {
            const agora = Date.now();
            let espera = 0;
            const regras = [[R.MIN, R.POR_MINUTO], [R.HORA, R.POR_HORA], [R.DIA, R.POR_DIA]];
            for (const [ms, max] of regras) {
                const usados = janela(ms);
                if (usados.length >= max) {
                    const libera = usados[usados.length - max] + ms - agora;
                    if (libera > espera) espera = libera;
                }
            }
            return espera;
        }

        async function esperar(ate, motivo) {
            while (!fechado && Date.now() < ate) {
                emitirFila(motivo, ate);
                await dormir(Math.min(1000, Math.max(50, ate - Date.now())));
            }
        }

        async function enviarUm(item) {
            const chave = item.chave;
            const alvo = item.jid;
            const guardada = ultimaChave.get(chave);
            if (guardada && !item.proprio) {
                try { await sock.readMessages([guardada]); } catch (e) {}
                await dormir(sorteio(R.LEITURA_MIN, R.LEITURA_MAX));
            }
            if (!item.proprio) {
                try { await sock.sendPresenceUpdate('composing', alvo); } catch (e) {}
                const base = R.DIGITANDO_BASE + item.texto.length * R.DIGITANDO_POR_LETRA;
                const digitando = Math.min(R.DIGITANDO_MAX, Math.max(R.DIGITANDO_MIN, base)) * (0.8 + Math.random() * 0.4);
                await dormir(digitando);
            }
            const enviada = await sock.sendMessage(alvo, { text: item.texto });
            lembrarEnviada(enviada && enviada.key && enviada.key.id);
            if (!item.proprio) {
                try { await sock.sendPresenceUpdate('paused', alvo); } catch (e) {}
            }
        }

        async function rodarFila() {
            if (rodando) return;
            rodando = true;
            try {
                while (fila.length && !fechado) {
                    if (node.estado !== 'online' || !sock) {
                        emitirFila('aguardando conexão', 0);
                        await dormir(2000);
                        continue;
                    }
                    const limite = esperaLimites();
                    if (limite > 0) {
                        await esperar(Date.now() + Math.min(limite, 5000), 'limite de envios');
                        continue;
                    }
                    if (Date.now() < liberaEm) {
                        await esperar(liberaEm, 'intervalo entre mensagens');
                        continue;
                    }
                    const item = fila[0];
                    try {
                        await enviarUm(item);
                        fila.shift();
                        const agora = Date.now();
                        envios.push(agora);
                        envios = envios.filter(t => agora - t < R.DIA);
                        gravarJson(arquivoEnvios, envios);
                        if (!item.proprio) recentes.push({ t: agora, texto: item.texto, chave: item.chave });
                        recentes = recentes.filter(r => agora - r.t < R.REPETICAO_JANELA);
                        let pausa = sorteio(R.INTERVALO_MIN, R.INTERVALO_MAX);
                        if (Math.random() < R.PAUSA_LONGA_CHANCE) pausa += sorteio(R.PAUSA_LONGA_MIN, R.PAUSA_LONGA_MAX);
                        liberaEm = agora + pausa;
                        node.eventos.emit('enviada', { chave: item.chave });
                    } catch (e) {
                        fila.shift();
                        node.eventos.emit('recusada', 'falha ao enviar: ' + (e && e.message ? e.message : e));
                    }
                    emitirFila('', 0);
                }
            } finally {
                rodando = false;
                emitirFila('', 0);
            }
        }

        node.enviar = function (grupo, numero, texto) {
            if (typeof texto !== 'string' || !texto.trim()) return { ok: false, motivo: 'mensagem vazia' };
            if (texto.length > R.TEXTO_MAX) return { ok: false, motivo: 'mensagem maior que ' + R.TEXTO_MAX + ' caracteres' };
            const chave = grupo ? String(grupo) : soDigitos(numero);
            if (!chave) return { ok: false, motivo: 'número ou grupo não informado' };
            const proprio = !grupo && !!node.numero && R.canonico(chave) === R.canonico(node.numero);
            let achada = chave;
            if (!proprio && !grupo && !contatos[chave]) {
                const igual = Object.keys(contatos).find(k => !k.endsWith('@g.us') && R.canonico(k) === R.canonico(chave));
                if (igual) achada = igual;
            }
            const contato = proprio ? { jid: node.numero + '@s.whatsapp.net' } : contatos[achada];
            if (!contato || (!proprio && Date.now() - contato.t > R.CONTATO_VALIDADE)) {
                return { ok: false, motivo: 'recusada: ' + chave + ' não escreveu para você nos últimos 30 dias' };
            }
            if (!proprio) {
                const agora = Date.now();
                const iguais = new Set();
                for (const r of recentes) {
                    if (agora - r.t < R.REPETICAO_JANELA && r.texto === texto) iguais.add(r.chave);
                }
                for (const f of fila) {
                    if (f.texto === texto) iguais.add(f.chave);
                }
                if (!iguais.has(achada) && iguais.size >= R.REPETICAO_MAX_NUMEROS) {
                    return { ok: false, motivo: 'recusada: mesmo texto já foi para ' + iguais.size + ' números há pouco' };
                }
            }
            if (fila.length >= R.FILA_MAX) return { ok: false, motivo: 'fila cheia (' + R.FILA_MAX + ')' };
            fila.push({ chave: achada, jid: contato.jid, texto: texto, proprio: proprio });
            emitirFila('', 0);
            rodarFila();
            return { ok: true };
        };

        function agendarReconexao() {
            if (fechado) return;
            tentativas++;
            const espera = Math.min(300000, 5000 * Math.pow(2, Math.min(tentativas - 1, 6)));
            mudar('reconectando', 'nova tentativa em ' + Math.round(espera / 1000) + ' s');
            reconexao = setTimeout(() => {
                reconexao = null;
                conectar();
            }, espera);
        }

        function limparSessao() {
            try { fs.rmSync(pasta, { recursive: true, force: true }); } catch (e) {}
            contatos = {};
            envios = [];
            carregarArquivos();
        }

        async function conectar() {
            if (fechado || conectando) return;
            conectando = true;
            try {
                const b = await carregar();
                fs.mkdirSync(pasta, { recursive: true });
                const { state, saveCreds } = await b.useMultiFileAuthState(pasta);
                const criar = b.makeWASocket || b.default;
                const atual = criar({
                    auth: state,
                    logger: silencioso,
                    browser: b.Browsers.windows('Chrome'),
                    markOnlineOnConnect: false,
                    syncFullHistory: false,
                    generateHighQualityLinkPreview: false
                });
                sock = atual;
                atual.ev.on('creds.update', saveCreds);
                atual.ev.on('messages.upsert', async (ev) => {
                    if (ev.type !== 'notify') return;
                    for (const m of ev.messages) {
                        try { await receber(m); } catch (e) {}
                    }
                });
                atual.ev.on('connection.update', (u) => {
                    if (sock !== atual) return;
                    if (u.qr) {
                        const q = qrcode(0, 'M');
                        q.addData(u.qr);
                        q.make();
                        node.qrSvg = q.createSvgTag({ cellSize: 4, margin: 2, scalable: true });
                        mudar('aguardando_qr', 'escaneie o QR no celular');
                    }
                    if (u.connection === 'open') {
                        tentativas = 0;
                        node.qrSvg = null;
                        node.numero = soDigitos(atual.user && atual.user.id);
                        mudar('online', node.numero);
                        rodarFila();
                    }
                    if (u.connection === 'close') {
                        const erro = u.lastDisconnect && u.lastDisconnect.error;
                        const codigo = erro && erro.output && erro.output.statusCode;
                        sock = null;
                        node.qrSvg = null;
                        const D = b.DisconnectReason;
                        if (codigo === D.loggedOut) {
                            limparSessao();
                            mudar('sem_login', 'aparelho desvinculado; gere um novo QR');
                        } else if (codigo === D.connectionReplaced) {
                            mudar('substituida', 'o número abriu em outro lugar; clique em Conectar para voltar');
                        } else if (codigo === D.restartRequired) {
                            conectando = false;
                            conectar();
                        } else if (codigo === D.timedOut && !temSessao()) {
                            mudar('sem_login', 'QR expirou; clique em Conectar para gerar outro');
                        } else {
                            agendarReconexao();
                        }
                    }
                });
            } catch (e) {
                sock = null;
                mudar('erro', e && e.message ? e.message : String(e));
                agendarReconexao();
            } finally {
                conectando = false;
            }
        }

        node.iniciarLogin = async function () {
            if (node.estado === 'online') return;
            if (reconexao) {
                clearTimeout(reconexao);
                reconexao = null;
            }
            if (sock) {
                const velho = sock;
                sock = null;
                try { velho.end(undefined); } catch (e) {}
            }
            tentativas = 0;
            mudar('conectando', '');
            await conectar();
        };

        node.desvincular = async function () {
            if (reconexao) {
                clearTimeout(reconexao);
                reconexao = null;
            }
            const atual = sock;
            sock = null;
            if (atual) {
                try { await atual.logout(); } catch (e) {}
                try { atual.end(undefined); } catch (e) {}
            }
            fila = [];
            node.qrSvg = null;
            node.numero = null;
            limparSessao();
            mudar('sem_login', 'desvinculado');
        };

        carregarArquivos();
        if (temSessao()) {
            mudar('conectando', '');
            conectar();
        } else {
            mudar('sem_login', 'aguardando QR');
        }

        node.temSessao = temSessao;

        node.fechar = function () {
            fechado = true;
            if (reconexao) clearTimeout(reconexao);
            if (sock) {
                try { sock.end(undefined); } catch (e) {}
                sock = null;
            }
            node.eventos.removeAllListeners();
        };

        node.apagarPasta = function () {
            try { fs.rmSync(pasta, { recursive: true, force: true }); } catch (e) {}
        };

        return node;
    }

    function obter(id) {
        let n = nucleos.get(id);
        if (!n) {
            n = criarNucleo(id);
            nucleos.set(id, n);
        }
        return n;
    }

    function Conta(config) {
        RED.nodes.createNode(this, config);
        const self = this;
        self.name = config.name;
        const n = obter(self.id);
        n.adotado = true;
        n.ultimoAcesso = Date.now();
        self.eventos = n.eventos;
        self.enviar = n.enviar;
        ['estado', 'detalhe', 'qrSvg', 'numero'].forEach(campo => {
            Object.defineProperty(self, campo, { get: () => n[campo] });
        });

        self.on('close', function (removido, feito) {
            if (typeof removido === 'function') {
                feito = removido;
                removido = false;
            }
            n.adotado = false;
            n.ultimoAcesso = Date.now();
            if (removido) {
                n.fechar();
                nucleos.delete(self.id);
            }
            feito();
        });
    }

    RED.nodes.registerType('whatsapp-conta', Conta);

    const vigia = setInterval(() => {
        const agora = Date.now();
        for (const [id, n] of nucleos) {
            if (n.adotado) continue;
            const ocioso = agora - n.ultimoAcesso;
            if (n.estado !== 'online' && ocioso > 60000) {
                n.fechar();
                if (!n.temSessao()) n.apagarPasta();
                nucleos.delete(id);
            } else if (n.estado === 'online' && ocioso > 900000) {
                nucleos.delete(id);
                n.desvincular().then(() => n.fechar()).catch(() => n.fechar());
            }
        }
    }, 30000);
    vigia.unref();

    function valido(id) {
        return /^[A-Za-z0-9_.-]{1,64}$/.test(String(id || ''));
    }

    RED.httpAdmin.get('/whatsapp/:id/estado', RED.auth.needsPermission('flows.write'), (req, res) => {
        if (!valido(req.params.id)) return res.status(400).json({ erro: 'id inválido' });
        const c = obter(req.params.id);
        c.ultimoAcesso = Date.now();
        if ((c.estado === 'sem_login' || c.estado === 'parado') && !c.temSessao()) c.iniciarLogin();
        res.json({ estado: c.estado, detalhe: c.detalhe, numero: c.numero, qr: c.qrSvg, regras: R.RESUMO });
    });

};
