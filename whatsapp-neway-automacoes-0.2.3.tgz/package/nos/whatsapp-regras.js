const MIN = 60 * 1000;
const HORA = 60 * MIN;
const DIA = 24 * HORA;

function canonico(valor) {
    const d = String(valor || '').split('@')[0].split(':')[0].replace(/\D/g, '');
    if (d.length === 12 && d.startsWith('55') && /[6-9]/.test(d[4])) return d.slice(0, 4) + '9' + d.slice(4);
    return d;
}

module.exports = Object.freeze({
    canonico,
    INTERVALO_MIN: 5000,
    INTERVALO_MAX: 15000,
    POR_MINUTO: 4,
    POR_HORA: 60,
    POR_DIA: 200,
    LEITURA_MIN: 1000,
    LEITURA_MAX: 3000,
    DIGITANDO_BASE: 800,
    DIGITANDO_POR_LETRA: 60,
    DIGITANDO_MIN: 1500,
    DIGITANDO_MAX: 9000,
    PAUSA_LONGA_CHANCE: 0.1,
    PAUSA_LONGA_MIN: 30000,
    PAUSA_LONGA_MAX: 90000,
    FILA_MAX: 50,
    TEXTO_MAX: 4000,
    CONTATO_VALIDADE: 30 * DIA,
    REPETICAO_JANELA: 10 * MIN,
    REPETICAO_MAX_NUMEROS: 2,
    MIN,
    HORA,
    DIA,
    RESUMO: 'Envio protegido: intervalo aleatório de 5 a 15 s entre mensagens, máximo de 4 por minuto, 60 por hora e 200 por dia. Só responde a quem já escreveu para você nos últimos 30 dias (exceto o seu próprio número). Lê a mensagem e mostra "digitando" antes de enviar, faz pausas longas de vez em quando e segura texto repetido para vários números. Valores fixos, não configuráveis.'
});
